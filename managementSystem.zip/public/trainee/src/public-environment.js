
export const toastrOptions = {
  positionClass: 'toast-top-left',
  closeButton: true
};
