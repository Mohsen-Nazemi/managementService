export class PageObjectSkeleton {
  getCurrentPageTitle() {
    return browser.getTitle();
  }
}
