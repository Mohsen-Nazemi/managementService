#! venv/bin python3

def load_model():
    print('ok')


# Functions
def sample2_function1():
    return "file: sample2 | This is sample2_function1 from sample2 file"


def sample2_function2():
    return "file: sample2 | This is sample2_function2 from sample2 file"
