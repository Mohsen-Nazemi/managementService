exports.f1PostHeader = {
  // برای اطلاعات بیشتر به این آدرس سر بزنید
  // http://192.168.1.93/mediawiki/index.php/Part_Json_Validator
};
exports.f1PostData = {
  // برای اطلاعات بیشتر به این آدرس سر بزنید
  // http://192.168.1.93/mediawiki/index.php/Part_Json_Validator
};
exports.f1GetHeader = {
  // برای اطلاعات بیشتر به این آدرس سر بزنید
  // http://192.168.1.93/mediawiki/index.php/Part_Json_Validator
};
exports.f1GetData = {
  // برای اطلاعات بیشتر به این آدرس سر بزنید
  // http://192.168.1.93/mediawiki/index.php/Part_Json_Validator
};
