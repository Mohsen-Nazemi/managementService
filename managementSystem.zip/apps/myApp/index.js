let httpHandlers = require('./lib/httpHandlers.js');


module.exports = {
  httpHandlers: httpHandlers.httpHandlers
};